
package sistemausuario;

import sistemausuario.view.TelaInicial;

public class SistemaUsuario {

    public static void main(String[] args) {
       TelaInicial ti = new TelaInicial();
       ti.setVisible(true);
    }
    
}
