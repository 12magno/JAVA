 package sistemausuario.dao;

  //import java.awt.Component;
 //import java.net.URL;
import java.net.URL;
import java.sql.DriverManager;
import sistemausuario.core.emity.Usuario;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.ResultSet;

 //import javax.swing.JOptionPane;


public class UsuarioDAO {
  private   Connection connection; 
   //public Object usuarioDAO;
    

    public UsuarioDAO(Connection conexao) {
        connection = conexao;
        
    }
    public void inserir(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO usuario (nome, login, senha, email) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getLogin());
            stmt.setString(3, usuario.getSenha());
            stmt.setString(4, usuario.getEmail());
            stmt.executeUpdate();
           
            System.out.println("Cadastro efetuado com sucesso");
            // JOptionPane.showMessageDialog(null,"O campo esta vazio!!");
        } catch (SQLException ex) {
             
            throw new RuntimeException("Erro ao inserir usuário ", ex);
            
        }
    }

    public boolean validarLogin(String login, String senha) {
 try (Connection connection = DriverManager.getConnection(senha, senha, senha)) {
            String sql = "SELECT id, nome, login, senha, email FROM usuario WHERE login = ? AND senha = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, login);
            statement.setString(2, senha);

            ResultSet resultSet = statement.executeQuery();

            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }}
