/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sistemausuario.core.dao.conexao;
import java.sql.*;
 //import com.sun.jdi.connect.spi.Connection;

/**
 *
 * @author Magno
 */
public class Conexao {
   private Connection Connection;
    public Connection getConnection() {
    return this.Connection;
}

    public Conexao() {
        try {
            Class.forName("org.postgresql.Driver");
            String URL = "jdbc:postgresql://localhost:5432/MAPA";
            String USUARIO = "postgres";
            String SENHA = "98010245";
           Connection = (Connection) DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException | SQLException ex) {
            throw new RuntimeException("Erro ao conectar ao banco de dados", ex);
        }  
    }
    
}
